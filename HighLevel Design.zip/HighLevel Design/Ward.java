package smartcity;

/**
 * Created by minchu on 21/04/16.
 */
public class Ward {

    public int wardNumber;
    public Corporator corporator;
    public int population;
    public int amountSpent;
    public String kml;

    /** Returns the string of all the ward numbers. This is for the chart. */
    public String getAllWardNumbersString(){

    }

    /** Returns the string of meanings of all the wards. This is for the chart.*/
    public String getAllWardMeaningsString(){

    }

    /** Returns the string of total works in all wards. This is for the chart.*/
    public String getTotalWorksString(){

    }

    /** Returns the string of inprogess works in all wards. This is for the chart. */
    public String getInprogressWorksString(){

    }

    /** Returns the string of completed works in all wards. This is for the chart. */
    public String getCompletedWorks(){

    }

    /** Returns the string of total amount spent in all wards. This is for the chart. */
    public String getTotalAmountsSpent(){

    }
}