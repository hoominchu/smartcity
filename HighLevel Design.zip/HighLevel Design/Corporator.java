package smartcity;

/**
 * Created by minchu on 21/04/16.
 */
public class Corporator {

    public int ID;
    public String name;
    public String sex;
    public String party;
    public String termsServed; 		//AND/OR some other historical fact about the corporator. 
    public String linkToPersonalWebpage;	//Or myneta.gov profile. 
    public String address;
    public String emailID;
    public String phoneNumber;

}