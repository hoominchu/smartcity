package smartcity;

/**
 * Created by minchu on 21/04/16.
 */
public class Contractor {

    public int ID;
    public String name;	
    public int incompleteWorks;
    public int completedWorks;
    public int totalWorks;
    public String[] typesOfWorksDone;
    public String linkToPersonalWebpage;	
    public String address;
    public String emailID;
    public String phoneNumber;
    public int totalContractAmount;

}