package smartcity;

/**
 * Created by minchu on 15/04/16.
 */
public class functionsGeneral {

    /** Capitalizes the first letter of a string and returns it. */
    public static String capitalizeFirstLetter(String input) {
        return output;
    }

    /** Sets the final description that is to be displayed based on the language parameter in the URL. Arguments to be given are language parameter, description in English, description in Kannada and the work object. Returns the final description to be displayed. */
    public String setWorkDescriptionFinal (String languageParameter, String workDescriptionEnglish, String workDescriptionKannada){

        return workDescriptionFinal;
    }

    /** Generates the basic dynamic link given the URL request and FILTERS set */
    public String genLink (String request, Array filters){
        
    }

}
